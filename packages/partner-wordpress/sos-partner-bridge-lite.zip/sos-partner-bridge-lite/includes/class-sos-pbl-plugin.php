<?php

if (!defined('ABSPATH')) {
    exit;
}

class SOS_PBL_Plugin {
    private static $instance = null;

    /** @var SOS_PBL_Config */
    private $config;

    /** @var SOS_PBL_Central_Client */
    private $client;

    /** @var SOS_PBL_Settings_Page */
    private $settings_page;

    /** @var SOS_PBL_Handoff_Service */
    private $handoff_service;

    /** @var SOS_PBL_Payment_Callback */
    private $payment_callback;

    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    private function __construct() {
        $this->config = new SOS_PBL_Config();
        $this->client = new SOS_PBL_Central_Client($this->config);
        $this->settings_page = new SOS_PBL_Settings_Page($this->config);
        $this->handoff_service = new SOS_PBL_Handoff_Service($this->config, $this->client);
        $this->payment_callback = new SOS_PBL_Payment_Callback($this->config, $this->client);

        register_activation_hook(SOS_PBL_FILE, [$this, 'activate']);

        add_action('init', [$this, 'register_routes_placeholder']);
    }

    public function activate() {
        $this->config->ensure_defaults();
    }

    public function register_routes_placeholder() {
        // Placeholder only: route registration will be introduced in next implementation phase.
    }
}
