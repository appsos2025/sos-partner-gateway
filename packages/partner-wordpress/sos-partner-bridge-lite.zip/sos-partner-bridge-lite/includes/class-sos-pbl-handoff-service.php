<?php

if (!defined('ABSPATH')) {
    exit;
}

class SOS_PBL_Handoff_Service {
    /** @var SOS_PBL_Config */
    private $config;

    /** @var SOS_PBL_Central_Client */
    private $client;

    public function __construct(SOS_PBL_Config $config, SOS_PBL_Central_Client $client) {
        $this->config = $config;
        $this->client = $client;
    }

    public function build_handoff_payload($email) {
        $settings = $this->config->get();

        return [
            'partner_id' => (string) $settings['partner_id'],
            'email' => sanitize_email((string) $email),
            'timestamp' => time(),
            'nonce' => wp_generate_password(12, false, false),
        ];
    }

    public function send_handoff_request(array $payload) {
        // Placeholder endpoint path; actual contract with central plugin will be wired later.
        return $this->client->post('/wp-json/sos-partner/v1/handoff', $payload);
    }
}
