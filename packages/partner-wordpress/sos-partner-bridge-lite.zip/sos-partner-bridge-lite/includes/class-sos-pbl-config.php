<?php

if (!defined('ABSPATH')) {
    exit;
}

class SOS_PBL_Config {
    private $option_key = 'sos_pbl_settings';

    public function get_option_key() {
        return $this->option_key;
    }

    public function defaults() {
        return [
            'partner_id' => '',
            'central_base_url' => '',
            'integration_mode' => 'handoff_login',
            'shared_secret' => '',
            'handoff_endpoint_path' => '/wp-json/sos-partner/v1/handoff',
            'payment_callback_path' => '/wp-json/sos-partner/v1/payment-callback',
            'embedded_entrypoint_path' => '/wp-json/sos-partner/v1/embedded-booking',
            'debug_enabled' => 0,
        ];
    }

    public function ensure_defaults() {
        if (get_option($this->option_key, null) === null) {
            add_option($this->option_key, $this->defaults());
        }
    }

    public function get() {
        $settings = get_option($this->option_key, []);
        if (!is_array($settings)) {
            $settings = [];
        }

        return wp_parse_args($settings, $this->defaults());
    }

    public function update(array $settings) {
        $clean = [
            'partner_id' => sanitize_text_field((string) ($settings['partner_id'] ?? '')),
            'central_base_url' => esc_url_raw((string) ($settings['central_base_url'] ?? '')),
            'integration_mode' => sanitize_text_field((string) ($settings['integration_mode'] ?? 'handoff_login')),
            'shared_secret' => sanitize_text_field((string) ($settings['shared_secret'] ?? '')),
            'handoff_endpoint_path' => sanitize_text_field((string) ($settings['handoff_endpoint_path'] ?? '/wp-json/sos-partner/v1/handoff')),
            'payment_callback_path' => sanitize_text_field((string) ($settings['payment_callback_path'] ?? '/wp-json/sos-partner/v1/payment-callback')),
            'embedded_entrypoint_path' => sanitize_text_field((string) ($settings['embedded_entrypoint_path'] ?? '/wp-json/sos-partner/v1/embedded-booking')),
            'debug_enabled' => !empty($settings['debug_enabled']) ? 1 : 0,
        ];

        foreach (['handoff_endpoint_path', 'payment_callback_path', 'embedded_entrypoint_path'] as $path_key) {
            $value = trim((string) $clean[$path_key]);
            if ($value !== '' && $value[0] !== '/') {
                $value = '/' . $value;
            }
            $clean[$path_key] = $value;
        }

        if (!in_array($clean['integration_mode'], ['handoff_login', 'embedded_booking', 'payment_callback', 'combined'], true)) {
            $clean['integration_mode'] = 'handoff_login';
        }

        update_option($this->option_key, $clean, false);

        return $clean;
    }

    public function is_debug_enabled() {
        $settings = $this->get();
        return !empty($settings['debug_enabled']);
    }
}
