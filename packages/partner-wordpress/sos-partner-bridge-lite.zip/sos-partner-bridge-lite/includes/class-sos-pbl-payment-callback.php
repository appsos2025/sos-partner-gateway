<?php

if (!defined('ABSPATH')) {
    exit;
}

class SOS_PBL_Payment_Callback {
    /** @var SOS_PBL_Config */
    private $config;

    /** @var SOS_PBL_Central_Client */
    private $client;

    public function __construct(SOS_PBL_Config $config, SOS_PBL_Central_Client $client) {
        $this->config = $config;
        $this->client = $client;
    }

    public function build_payment_payload($booking_id, $transaction_id, $amount = null) {
        $settings = $this->config->get();

        $payload = [
            'partner_id' => (string) $settings['partner_id'],
            'booking_id' => absint($booking_id),
            'transaction_id' => sanitize_text_field((string) $transaction_id),
        ];

        if ($amount !== null) {
            $payload['amount_paid'] = (float) $amount;
        }

        return $payload;
    }

    public function send_payment_callback(array $payload) {
        // Placeholder endpoint path; exact callback contract will be configured in next phase.
        return $this->client->post('/wp-json/sos-partner/v1/payment-callback', $payload);
    }
}
