<?php
/**
 * Plugin Name: SOS Partner Bridge Lite
 * Description: Lightweight companion plugin for WordPress partners integrating with SOS central gateway.
 * Version: 0.1.0
 * Author: VB
 * Text Domain: sos-partner-bridge-lite
 */

if (!defined('ABSPATH')) {
    exit;
}

define('SOS_PBL_FILE', __FILE__);
define('SOS_PBL_DIR', plugin_dir_path(__FILE__));
define('SOS_PBL_VERSION', '0.1.0');

require_once SOS_PBL_DIR . 'includes/class-sos-pbl-config.php';
require_once SOS_PBL_DIR . 'includes/class-sos-pbl-central-client.php';
require_once SOS_PBL_DIR . 'includes/class-sos-pbl-settings-page.php';
require_once SOS_PBL_DIR . 'includes/class-sos-pbl-handoff-service.php';
require_once SOS_PBL_DIR . 'includes/class-sos-pbl-payment-callback.php';
require_once SOS_PBL_DIR . 'includes/class-sos-pbl-plugin.php';

SOS_PBL_Plugin::instance();
