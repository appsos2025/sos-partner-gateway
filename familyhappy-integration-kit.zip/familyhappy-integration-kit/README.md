# Family+Happy → SOS Medico / SOS Partner Gateway

Questo kit contiene la documentazione operativa proposta per l'integrazione diretta Family+Happy → SOS.

Scopo del flusso:
- Family+Happy invia a SOS una richiesta server-to-server per avviare il percorso di prenotazione.
- SOS valida la richiesta.
- SOS restituisce un `redirect_url` e un oggetto `handoff`.
- Family+Happy inoltra l'handoff ricevuto a `/partner-login/` senza modificarlo.
- Dopo il pagamento, Family+Happy invia una callback server-to-server firmata.

Regole base:
- una sola integrazione supportata: custom server-to-server;
- firma HMAC-SHA256 con secret dedicato al partner;
- `partner_id`, `email`, `external_reference`, `timestamp`, `nonce` e firma sono obbligatori;
- se i campi minimi o la firma non sono validi, la richiesta viene rifiutata;
- `first_name`, `last_name`, `phone` sono applicativi: consigliati ma non bloccanti.

Documenti principali:
- `familyhappy-integration-guide.md`
- `familyhappy-security-spec.md`
- `familyhappy-implementation-checklist.md`

Cartella esempi:
- payload JSON
- esempi Node.js e PHP
- esempio di POST handoff
- esempio callback pagamento
