<?php
$secret = getenv('SOS_PARTNER_SECRET') ?: 'replace-me';

$payload = [
    'partner_id' => 'familyhappy',
    'external_reference' => 'FH-2026-000123',
    'email' => 'mario.rossi@example.com',
    'first_name' => 'Mario',
    'last_name' => 'Rossi',
    'phone' => '+393331234567',
    'timestamp' => 1776501000,
    'nonce' => 'b4c92f0d9d6d4a9f8b1b32d8e5c0a77a',
];

$rawBody = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
$signature = hash_hmac('sha256', $rawBody, $secret);

echo "Raw body:\n" . $rawBody . PHP_EOL;
echo "X-SOSPG-Signature: " . $signature . PHP_EOL;
