const crypto = require('crypto');

async function main() {
  const url = 'https://staging.sosmedico.org/wp-json/sos-pg/v1/embedded-booking/create';
  const secret = process.env.SOS_PARTNER_SECRET || 'replace-me';

  const bodyObject = {
    partner_id: 'familyhappy',
    external_reference: 'FH-2026-000123',
    email: 'mario.rossi@example.com',
    first_name: 'Mario',
    last_name: 'Rossi',
    phone: '+393331234567',
    timestamp: 1776501000,
    nonce: 'b4c92f0d9d6d4a9f8b1b32d8e5c0a77a',
    return_url: 'https://my.familyhappybenefit.com/booking-return',
    token: 'token123',
    token_type: 'passthrough'
  };

  const rawBody = JSON.stringify(bodyObject);
  const signature = crypto.createHmac('sha256', secret).update(rawBody, 'utf8').digest('hex');

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-SOSPG-Signature': signature
    },
    body: rawBody
  });

  const text = await response.text();
  console.log('HTTP', response.status);
  console.log(text);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
