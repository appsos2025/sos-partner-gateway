# Codici risposta suggeriti

## embedded-booking/create

### 200
Richiesta accettata, handoff generato.

### 400
Payload JSON non valido o campi obbligatori mancanti.

### 401
Firma HMAC mancante o non valida.

### 403
Partner non abilitato, timestamp fuori finestra o nonce già utilizzato.

### 409
Riferimento partner duplicato, se gestito come conflitto.

## payment/callback

### 200
Callback accettata.

### 400
Body non valido.

### 401
Firma non valida.

### 403
Partner non autorizzato, timestamp fuori finestra o replay.

### 409
Evento già ricevuto, se trattato come duplicato.
