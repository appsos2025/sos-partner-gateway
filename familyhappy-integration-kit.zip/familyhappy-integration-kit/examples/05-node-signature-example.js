const crypto = require('crypto');

const secret = process.env.SOS_PARTNER_SECRET || 'replace-me';
const body = JSON.stringify({
  partner_id: 'familyhappy',
  external_reference: 'FH-2026-000123',
  email: 'mario.rossi@example.com',
  first_name: 'Mario',
  last_name: 'Rossi',
  phone: '+393331234567',
  timestamp: 1776501000,
  nonce: 'b4c92f0d9d6d4a9f8b1b32d8e5c0a77a'
});

const signature = crypto
  .createHmac('sha256', secret)
  .update(body, 'utf8')
  .digest('hex');

console.log('Raw body:', body);
console.log('X-SOSPG-Signature:', signature);
