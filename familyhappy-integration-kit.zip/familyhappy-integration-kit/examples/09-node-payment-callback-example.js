const crypto = require('crypto');

async function main() {
  const url = 'https://staging.sosmedico.org/wp-json/sos-pg/v1/payment/callback';
  const secret = process.env.SOS_PARTNER_SECRET || 'replace-me';

  const payload = {
    event: 'booking_paid',
    partner_id: 'familyhappy',
    external_reference: 'FH-2026-000123',
    booking_id: 209,
    status: 'paid',
    amount: 49.90,
    currency: 'EUR',
    transaction_id: 'PAY-99887766',
    email: 'mario.rossi@example.com',
    timestamp: 1776501900,
    nonce: '4c0f8461d0d44b19b3937a6f5d20f51b',
    paid_at: '2026-04-18T10:45:00+02:00'
  };

  const rawBody = JSON.stringify(payload);
  const signature = crypto.createHmac('sha256', secret).update(rawBody, 'utf8').digest('hex');

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-SOSPG-Signature': signature
    },
    body: rawBody
  });

  const text = await response.text();
  console.log('HTTP', response.status);
  console.log(text);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
