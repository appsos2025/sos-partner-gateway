<?php
$url = 'https://staging.sosmedico.org/wp-json/sos-pg/v1/embedded-booking/create';
$secret = getenv('SOS_PARTNER_SECRET') ?: 'replace-me';

$payload = [
    'partner_id' => 'familyhappy',
    'external_reference' => 'FH-2026-000123',
    'email' => 'mario.rossi@example.com',
    'first_name' => 'Mario',
    'last_name' => 'Rossi',
    'phone' => '+393331234567',
    'timestamp' => 1776501000,
    'nonce' => 'b4c92f0d9d6d4a9f8b1b32d8e5c0a77a',
    'return_url' => 'https://my.familyhappybenefit.com/booking-return',
    'token' => 'token123',
    'token_type' => 'passthrough',
];

$rawBody = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
$signature = hash_hmac('sha256', $rawBody, $secret);

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'X-SOSPG-Signature: ' . $signature,
    ],
    CURLOPT_POSTFIELDS => $rawBody,
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

if ($curlError) {
    echo 'cURL error: ' . $curlError . PHP_EOL;
    exit(1);
}

echo 'HTTP ' . $httpCode . PHP_EOL;
echo $response . PHP_EOL;
