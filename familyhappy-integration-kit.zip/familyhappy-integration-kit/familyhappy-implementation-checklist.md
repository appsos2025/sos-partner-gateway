# Checklist implementativa Family+Happy

## Prima di iniziare
- Confermare `partner_id` assegnato a Family+Happy.
- Confermare URL ambiente staging.
- Confermare URL ambiente produzione.
- Generare secret dedicato al partner.
- Concordare finestra timestamp.
- Concordare durata memorizzazione nonce lato SOS.

## Chiamata iniziale
- Serializzare il body JSON.
- Calcolare HMAC-SHA256 del raw body.
- Inviare header `X-SOSPG-Signature`.
- Inviare campi minimi: `partner_id`, `external_reference`, `email`, `timestamp`, `nonce`.
- Inviare opzionali: `first_name`, `last_name`, `phone`, `return_url`, `token`, `token_type`.

## Gestione risposta
- Verificare `success = true`.
- Leggere `redirect_url`.
- Leggere interamente `handoff`.
- Non alterare i cinque campi handoff.
- Inviare form POST a `redirect_url`.

## Pagamento
- Preparare body callback JSON.
- Calcolare HMAC-SHA256 del raw body.
- Inviare header `X-SOSPG-Signature`.
- Inviare `partner_id`, `external_reference`, `status`, `timestamp`, `nonce`.
- Inviare `booking_id`, `amount`, `currency`, `transaction_id`, `email`, `paid_at`.

## Test minimi
- test firma valida;
- test firma errata;
- test timestamp scaduto;
- test nonce duplicato;
- test campo obbligatorio mancante;
- test callback pagamento `paid`;
- test callback pagamento rifiutata.
