# Guida integrazione Family+Happy → SOS

## 1. Obiettivo

Family+Happy integra il booking SOS tramite una chiamata server-to-server.  
La risposta di SOS contiene i dati necessari per aprire il flusso partner su SOS.

L'integrazione supportata è una sola:
- integrazione custom server-to-server.

Non è prevista in questa specifica una variante WordPress.

## 2. Flusso logico

### Step 1 — Richiesta iniziale di avvio booking
Family+Happy invia una richiesta HTTP POST JSON a SOS per avviare il flusso.

Endpoint proposto:
`POST /wp-json/sos-pg/v1/embedded-booking/create`

### Step 2 — Verifica lato SOS
SOS esegue:
- controllo campi obbligatori;
- controllo `partner_id`;
- controllo finestra temporale del `timestamp`;
- controllo anti-replay del `nonce`;
- verifica firma HMAC-SHA256 del raw body.

Se la verifica fallisce, la richiesta viene rifiutata.

### Step 3 — Risposta di SOS
Se la verifica ha esito positivo, SOS restituisce:
- `success = true`
- `redirect_url`
- oggetto `handoff`

### Step 4 — Inoltro handoff
Family+Happy NON deve rigenerare l'handoff e NON deve modificare i valori ricevuti da SOS.

Family+Happy deve solo effettuare un POST HTML form verso `redirect_url` con i campi ricevuti in `handoff`.

### Step 5 — Callback pagamento
A pagamento completato, Family+Happy invia una callback firmata a SOS.

## 3. Campi richiesti nella chiamata iniziale

### Campi obbligatori
- `partner_id`
- `external_reference`
- `email`
- `timestamp`
- `nonce`

### Campi consigliati ma non bloccanti
- `first_name`
- `last_name`
- `phone`
- `return_url`
- `token`
- `token_type`

## 4. Payload iniziale proposto

```json
{
  "partner_id": "familyhappy",
  "external_reference": "FH-2026-000123",
  "email": "mario.rossi@example.com",
  "first_name": "Mario",
  "last_name": "Rossi",
  "phone": "+393331234567",
  "timestamp": 1776501000,
  "nonce": "b4c92f0d9d6d4a9f8b1b32d8e5c0a77a",
  "return_url": "https://my.familyhappybenefit.com/booking-return",
  "token": "token123",
  "token_type": "passthrough"
}
```

## 5. Risposta attesa di SOS

```json
{
  "success": true,
  "partner_id": "familyhappy",
  "redirect_url": "https://staging.sosmedico.org/partner-login/",
  "handoff": {
    "partner_id": "familyhappy",
    "payload": "mario.rossi@example.com",
    "timestamp": 1776501002,
    "nonce": "e91f9aa4d61d42d09a9b7c0d38dcfd0a",
    "signature": "BASE64_SIGNATURE_GENERATED_BY_SOS"
  },
  "normalized_payload": {
    "partner_id": "familyhappy",
    "external_reference": "FH-2026-000123",
    "email": "mario.rossi@example.com",
    "name": "Mario Rossi",
    "phone": "+393331234567",
    "token_type": "passthrough",
    "token_strategy": "passthrough"
  },
  "verification": {
    "ok": true,
    "strategy": "passthrough",
    "partner_id": "familyhappy",
    "external_reference": "FH-2026-000123",
    "errors": []
  }
}
```

## 6. Regole handoff

Family+Happy deve inviare a `redirect_url` un form POST con:
- `partner_id`
- `payload`
- `timestamp`
- `nonce`
- `signature`

Questi cinque campi devono essere trasmessi esattamente come ricevuti.

## 7. Callback pagamento proposta

Endpoint proposto:
`POST /wp-json/sos-pg/v1/payment/callback`

Payload proposto:

```json
{
  "event": "booking_paid",
  "partner_id": "familyhappy",
  "external_reference": "FH-2026-000123",
  "booking_id": 209,
  "status": "paid",
  "amount": 49.90,
  "currency": "EUR",
  "transaction_id": "PAY-99887766",
  "email": "mario.rossi@example.com",
  "timestamp": 1776501900,
  "nonce": "4c0f8461d0d44b19b3937a6f5d20f51b",
  "paid_at": "2026-04-18T10:45:00+02:00"
}
```

## 8. Regole applicative

- `email` è obbligatoria. Senza email la richiesta viene rifiutata.
- `external_reference` è obbligatoria e deve essere univoca lato Family+Happy.
- `timestamp` è obbligatorio e deve rientrare nella finestra temporale ammessa.
- `nonce` è obbligatorio e deve essere casuale e non riutilizzato.
- `first_name`, `last_name`, `phone` sono consigliati; se assenti, il flusso può partire ma il loro utilizzo non è garantito in precompilazione.

## 9. Errori attesi

### 400 Bad Request
Campi obbligatori mancanti o payload non valido.

### 401 Unauthorized
Firma mancante o non valida.

### 403 Forbidden
Partner non autorizzato, timestamp fuori finestra, nonce già utilizzato.

### 409 Conflict
`external_reference` duplicato, se la logica lato SOS lo tratta come conflitto.

### 200 OK
Richiesta accettata.
