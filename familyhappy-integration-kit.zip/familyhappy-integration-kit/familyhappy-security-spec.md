# Specifica sicurezza Family+Happy → SOS

## 1. Meccanismo di firma

Per le chiamate server-to-server il partner utilizza:
- HMAC-SHA256
- secret dedicato al partner
- firma del raw request body

Header proposto:
`X-SOSPG-Signature`

Formato proposto:
- firma esadecimale lower-case del digest HMAC-SHA256.

## 2. Regola di verifica

SOS verifica:
1. `partner_id` valido e abilitato;
2. presenza del secret associato a quel partner;
3. presenza dei campi minimi richiesti;
4. `timestamp` dentro la finestra ammessa;
5. `nonce` non riutilizzato;
6. corrispondenza tra firma ricevuta e HMAC-SHA256 del raw body.

Se anche uno solo di questi controlli fallisce, la richiesta viene rifiutata.

## 3. Campi minimi di sicurezza

Campi minimi richiesti nella richiesta iniziale:
- `partner_id`
- `external_reference`
- `email`
- `timestamp`
- `nonce`

Campi minimi richiesti nella callback pagamento:
- `partner_id`
- `external_reference`
- `status`
- `timestamp`
- `nonce`

## 4. Timestamp

Formato:
- Unix timestamp in secondi.

Regola proposta:
- tolleranza massima ±300 secondi.

## 5. Nonce

Regole:
- stringa casuale generata dal partner;
- minimo consigliato: 16 byte di entropia reale;
- ogni richiesta deve avere un nonce diverso;
- SOS deve memorizzare temporaneamente il nonce per prevenire replay.

Nota:
- il partner genera il nonce;
- SOS verifica unicità del nonce nella finestra temporale.

## 6. Raw body

La firma deve essere calcolata sul body JSON grezzo, esattamente come inviato nella richiesta HTTP.

Conseguenze:
- cambiare spazi, ordine dei campi o serializzazione dopo la firma può invalidare la verifica;
- la serializzazione deve essere stabile lato partner.

## 7. Cosa NON deve fare Family+Happy

Family+Happy non deve:
- rigenerare i campi `handoff` ricevuti da SOS;
- cambiare `payload`, `timestamp`, `nonce` o `signature` nell'handoff;
- firmare solo una parte del body;
- inviare richieste senza `partner_id`, `timestamp` o `nonce`;
- riutilizzare lo stesso nonce.

## 8. Esempio logico di verifica

1. leggere il raw body;
2. estrarre `partner_id`;
3. recuperare il secret del partner;
4. ricalcolare HMAC-SHA256(raw_body, secret);
5. confrontare con `X-SOSPG-Signature` in constant-time;
6. validare `timestamp`;
7. validare `nonce`;
8. proseguire solo se tutto è valido.

## 9. Esempio firma HMAC-SHA256

Pseudo-formula:

`signature = HMAC_SHA256_HEX(raw_body, partner_secret)`
